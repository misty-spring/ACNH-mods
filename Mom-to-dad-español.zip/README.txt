This is a mod meant for spanish-speaking players.

Este es un mod en español. Cambia las cartas de "mamá" a papá.
El mod también incluye una versión género-neutral. Para usar esta en vez, renombra "Mail_USes NEUTRAL" a "Mail_USes" (deberás borrar el otro archivo).