This is a mod meant for spanish-speaking players.

Este es un mod en español. Cambia (parcialmente) el lenguaje en el juego, para que se trate al jugador de forma género neutral.